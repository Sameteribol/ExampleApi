﻿using DatabaseExample.Core;
using DatabaseExample.Entities;

namespace DatabaseExample.Repositories.Abstracts;

public interface IJobberRepository : IBaseRepository<Jobber>
{
}